import json
import boto3
import uuid

s3_client = boto3.client("s3")
BUCKET_NAME = "dunviidy-s3"

def lambda_handler(event, context):
    file_name = str(uuid.uuid4()) + ".mp4"
    presigned_url = s3_client.generate_presigned_url(
        "put_object",
        Params={"Bucket": BUCKET_NAME, "Key": file_name, "ContentType": "video/mp4"},
        ExpiresIn=3600
    )

    return {
        "statusCode": 200,
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET",
            "Access-Control-Allow-Headers": "Content-Type",
            "Content-Type": "video/mp4"  # Ensure response is JSON
        },
        "body": json.dumps({"uploadURL": presigned_url})
    }
