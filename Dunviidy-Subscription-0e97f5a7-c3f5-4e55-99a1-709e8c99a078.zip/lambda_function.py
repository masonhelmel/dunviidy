import json
import boto3

# Initialize the SNS client
sns_client = boto3.client('sns')

def lambda_handler(event, context):
    # Define the subscription ARN (replace with your subscription ARN)
    sns_topic_arn = 'arn:aws:sns:us-east-1:851725284981:Dunviidy-SNS'

    # Define the message
    subject = "Test Email from AWS Lambda"
    message = "Hello, this is a test email sent through AWS SNS using Lambda."

    # Publish the message to the subscription ARN directly
    response = sns_client.publish(
        TargetArn=sns_topic_arn,  # Use the subscription ARN here
        Message=message,
        Subject=subject
    )

    # Log the response
    print(f"Email sent! Message ID: {response['MessageId']}")

    return {
        'statusCode': 200,
        'body': json.dumps('Email sent successfully')
    }
